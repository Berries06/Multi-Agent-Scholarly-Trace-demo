using System;
using System.Runtime.InteropServices;
using AgentDemoDesk.Forms;
using AgentDemoDesk.Utils;
using Newtonsoft.Json;

namespace AgentDemoDesk.Bridge
{
    /// <summary>
    /// 暴露给网页的桥。与 BMS_WinForms 同构：方法同步返回字符串，
    /// 需要操作界面的一律 BeginInvoke 回 UI 线程。
    /// 网页侧调用 window.chrome.webview.hostObjects.sync.bridge.xxx()。
    /// </summary>
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    public class JsBridge
    {
        private readonly MainForm _form;

        public JsBridge(MainForm form)
        {
            _form = form;
        }

        public string getAppInfo()
        {
            return JsonConvert.SerializeObject(new
            {
                app = StoreInfo.AppId,
                name = StoreInfo.AppName,
                version = StoreInfo.Version,
                baseUrl = _form.BaseUrl,
                webViewVersion = _form.WebViewVersion,
                dpiScale = ScreenInfo.ScaleText(ScreenInfo.DpiForWindow(_form.Handle)),
                os = Environment.OSVersion.VersionString,
                isDesktop = true
            });
        }

        public string getBaseUrl()
        {
            return _form.BaseUrl;
        }

        /// <summary>站外链接（GitHub、官网资源等）用系统默认浏览器打开。</summary>
        public void openExternal(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return;
            MainForm.OpenInBrowser(url);
        }

        public void printToPdf()
        {
            _form.BeginInvoke(new Action(() => _form.ExportPdf()));
        }

        public void reload()
        {
            _form.BeginInvoke(new Action(() => _form.Reload()));
        }

        public void goHome()
        {
            _form.BeginInvoke(new Action(() => _form.Navigate(_form.BaseUrl)));
        }

        public void showAbout()
        {
            _form.BeginInvoke(new Action(() => _form.ShowAboutDialog()));
        }

        public void signOut()
        {
            _form.BeginInvoke(new Action(() => _form.SignOut()));
        }

        /// <summary>网页可主动同步窗口标题（例如“运行中 · 3/6”）。</summary>
        public void setWindowTitle(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            _form.BeginInvoke(new Action(() => _form.SetWindowTitle(text)));
        }
    }
}
