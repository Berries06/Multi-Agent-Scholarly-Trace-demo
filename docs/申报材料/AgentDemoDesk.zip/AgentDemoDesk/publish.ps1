﻿param(
    [string]$Version = "V1.0",
    [switch]$SkipGit
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# V1.0 -> 1.0.0.0 ; V1.2.3 -> 1.2.3.0
$appVer = $Version -replace '^V', ''
$parts = $appVer.Split('.')
while ($parts.Length -lt 4) { $parts += "0" }
$asmVer = [string]::Join('.', $parts)

Write-Host "========================================"
Write-Host "Release: $Version  (Assembly: $asmVer)"
Write-Host "========================================"

# 仓库当前没有 .git 时不要 pretend 有：git 段默认跳过。
if (-not $SkipGit -and (Test-Path (Join-Path $scriptDir ".git"))) {
    Write-Host "[1/5] git pull ..."
    git pull
} else {
    Write-Host "[1/5] 跳过 git（无 .git 或显式 -SkipGit）"
}

Write-Host "[2/5] Build Release (ver $asmVer) ..."
$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
$msbuild = $null
if (Test-Path -LiteralPath $vswhere) {
    $msbuild = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild `
        -find "MSBuild\**\Bin\MSBuild.exe" | Select-Object -First 1
}
if (-not $msbuild) {
    $msbuildCommand = Get-Command msbuild -ErrorAction SilentlyContinue
    if ($msbuildCommand) { $msbuild = $msbuildCommand.Source }
}
if (-not $msbuild) {
    throw "MSBuild not found. Install Visual Studio or MSBuild Build Tools."
}

$csproj = Join-Path $scriptDir "AgentDemoDesk.csproj"
$asmPath = Join-Path $scriptDir "Properties\AssemblyInfo.cs"
$binDir = Join-Path $scriptDir "bin\Release"

$asmOrig = [System.IO.File]::ReadAllText($asmPath, [System.Text.Encoding]::UTF8)
$asmNew = $asmOrig -replace 'AssemblyVersion\("[^"]*"\)', "AssemblyVersion(""$asmVer"")"
$asmNew = $asmNew -replace 'AssemblyFileVersion\("[^"]*"\)', "AssemblyFileVersion(""$asmVer"")"
[System.IO.File]::WriteAllText($asmPath, $asmNew, (New-Object System.Text.UTF8Encoding($true)))

try {
    & $msbuild $csproj /t:Restore /p:Configuration=Release /v:m /nologo
    if ($LASTEXITCODE -ne 0) { throw "Release restore failed." }
    & $msbuild $csproj /t:Build /p:Configuration=Release /v:m /nologo
    if ($LASTEXITCODE -ne 0) { throw "Release build failed." }
}
finally {
    [System.IO.File]::WriteAllText($asmPath, $asmOrig, (New-Object System.Text.UTF8Encoding($true)))
}

Write-Host "[3/5] Package ..."
$releaseDir = Join-Path $scriptDir "release"
$appDir = Join-Path $releaseDir "AgentDemoDesk_$Version"
$zipPath = Join-Path $releaseDir "AgentDemoDesk-Windows-x64-$Version.zip"

if (Test-Path -LiteralPath $appDir) { Remove-Item -LiteralPath $appDir -Recurse -Force }
New-Item -ItemType Directory -Path $appDir -Force | Out-Null
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }

# 发布包必须自带 config.json：它是服务器地址的默认值与可编辑模板。
# 只排除运行产物与调试符号（WebView2 缓存、日志、pdb）。
$excludedNames = @(
    "AgentDemoDesk.exe.WebView2",
    "WebView2Data",
    "logs",
    "AgentDemoDesk.pdb"
)
Get-ChildItem -LiteralPath $binDir -Force |
    Where-Object { $excludedNames -notcontains $_.Name } |
    ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $appDir -Recurse -Force
    }

Compress-Archive -Path "$appDir\*" -DestinationPath $zipPath

Write-Host "[4/5] Integrity ..."
$hash = Get-FileHash -LiteralPath $zipPath -Algorithm SHA256
$size = (Get-Item -LiteralPath $zipPath).Length

Write-Host "========================================"
Write-Host "[5/5] Release $Version completed"
Write-Host "  App     : $appDir"
Write-Host "  Zip     : $zipPath"
Write-Host "  Bytes   : $size"
Write-Host "  SHA-256 : $($hash.Hash.ToLowerInvariant())"
Write-Host "========================================"
