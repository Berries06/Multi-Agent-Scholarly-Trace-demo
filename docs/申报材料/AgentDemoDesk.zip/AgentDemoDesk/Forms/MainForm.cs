using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using AgentDemoDesk.Bridge;
using AgentDemoDesk.Utils;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using Newtonsoft.Json;

namespace AgentDemoDesk.Forms
{
    /// <summary>
    /// 无边框内嵌浏览器：窗口里除网页外没有任何常驻 UI（无菜单栏、无状态栏）。
    /// 所有原生功能通过右键菜单与快捷键进入，提示通过注入网页的右下角 toast 呈现。
    /// 界面密度完全跟随系统 DPI（PerMonitorV2，不做强制缩放）。
    /// </summary>
    public class MainForm : Form
    {
        internal WebView2 webView;

        private CoreWebView2 _core;
        private readonly AppConfig _config;
        private readonly string _baseDir;

        private Panel _overlay;
        private Label _overlayTitle;
        private Label _overlayDetail;
        private Button _retryButton;
        private Button _browserButton;

        private string _pendingToast;

        public MainForm()
        {
            _config = AppConfig.Load();
            _baseDir = AppDomain.CurrentDomain.BaseDirectory;

            AutoScaleMode = AutoScaleMode.Dpi;
            Text = StoreInfo.AppName;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(_config.WindowWidth, _config.WindowHeight);
            MinimumSize = new Size(960, 640);
            Icon = LoadAppIcon();

            ApplyInitialWindowState();
            BuildOverlay();

            Load += (s, e) => InitializeWebView();
            FormClosing += OnFormClosing;
        }

        public string BaseUrl
        {
            get { return _config.BaseUrl; }
        }

        public string WebViewVersion
        {
            get
            {
                try
                {
                    if (_core != null) return _core.Environment.BrowserVersionString;
                }
                catch { }
                return "未知";
            }
        }

        // ---------------------------------------------------------------- 初始化

        private Icon LoadAppIcon()
        {
            try
            {
                string path = Path.Combine(_baseDir, "Assets", "AgentDemoDesk.ico");
                if (File.Exists(path)) return new Icon(path);
            }
            catch { }
            return SystemIcons.Application;
        }

        private void ApplyInitialWindowState()
        {
            bool restored = false;
            if (_config.RememberWindowState &&
                _config.WindowLeft != int.MinValue && _config.WindowTop != int.MinValue)
            {
                Rectangle bounds = new Rectangle(_config.WindowLeft, _config.WindowTop,
                    _config.WindowWidth, _config.WindowHeight);

                foreach (Screen screen in Screen.AllScreens)
                {
                    if (screen.WorkingArea.IntersectsWith(bounds)) { restored = true; break; }
                }

                if (restored)
                {
                    StartPosition = FormStartPosition.Manual;
                    Bounds = bounds;
                    if (_config.WindowMaximized) WindowState = FormWindowState.Maximized;
                }
            }

            if (!restored && _config.StartMaximized)
                WindowState = FormWindowState.Maximized;
        }

        private void BuildOverlay()
        {
            _overlay = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(242, 240, 235), Visible = true };

            _overlayTitle = new Label
            {
                Text = "正在连接研海寻踪…",
                Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 57, 50),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 90
            };

            _overlayDetail = new Label
            {
                Text = "首次启动需要联网登录；登录状态保存在本机（服务端会话 14 天）。",
                Font = new Font("Microsoft YaHei UI", 9F),
                ForeColor = Color.FromArgb(90, 100, 96),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.TopCenter
            };

            FlowLayoutPanel buttons = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = true,
                Dock = DockStyle.Bottom,
                Height = 64,
                Padding = new Padding(0, 8, 0, 18),
                WrapContents = false
            };

            FlowLayoutPanel center = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = true,
                Anchor = AnchorStyles.None,
                WrapContents = false
            };

            _retryButton = new Button { Text = "重试", AutoSize = true, MinimumSize = new Size(110, 34), Visible = false };
            _retryButton.Click += (s, e) => Reload();
            _browserButton = new Button { Text = "在浏览器中打开", AutoSize = true, MinimumSize = new Size(140, 34), Visible = false };
            _browserButton.Click += (s, e) => OpenInBrowser(CurrentUrl);

            center.Controls.Add(_retryButton);
            center.Controls.Add(_browserButton);
            buttons.Controls.Add(center);

            _overlay.Controls.Add(_overlayDetail);
            _overlay.Controls.Add(buttons);
            _overlay.Controls.Add(_overlayTitle);
            Controls.Add(_overlay);
            _overlay.BringToFront();
        }

        private async void InitializeWebView()
        {
            try
            {
                webView = new WebView2
                {
                    Dock = DockStyle.Fill,
                    CreationProperties = new CoreWebView2CreationProperties
                    {
                        UserDataFolder = _config.ResolvedUserDataFolder()
                    }
                };
                Controls.Add(webView);
                webView.SendToBack();

                await webView.EnsureCoreWebView2Async();
                _core = webView.CoreWebView2;

                // 无菜单栏：右键菜单是唯一的原生入口，必须保留上下文菜单。
                _core.Settings.AreDefaultContextMenusEnabled = true;
                _core.Settings.AreDevToolsEnabled = _config.AllowDevTools || Debugger.IsAttached;
                _core.Settings.IsStatusBarEnabled = false;
                // 按要求不做滚轮/快捷键缩放，界面密度只跟随系统 DPI。
                _core.Settings.IsZoomControlEnabled = false;
                _core.Settings.AreBrowserAcceleratorKeysEnabled = true;
                webView.ZoomFactor = 1.0;

                _core.NewWindowRequested += OnNewWindowRequested;
                _core.NavigationStarting += OnNavigationStarting;
                _core.NavigationCompleted += OnNavigationCompleted;
                _core.DocumentTitleChanged += OnDocumentTitleChanged;
                _core.DownloadStarting += OnDownloadStarting;
                _core.ProcessFailed += OnProcessFailed;
                _core.ContextMenuRequested += OnContextMenuRequested;
                _core.AddHostObjectToScript("bridge", new JsBridge(this));

                await InjectPageScriptAsync();

                _core.Navigate(_config.BaseUrl);
            }
            catch (Exception ex)
            {
                ShowError("WebView2 初始化失败", DescribeWebViewError(ex));
            }
        }

        /// <summary>注入 toast / 快捷键 / 429 重试脚本；不改动线上网页源码。</summary>
        private async System.Threading.Tasks.Task InjectPageScriptAsync()
        {
            try
            {
                string path = Path.Combine(_baseDir, "Assets", "inject.js");
                if (!File.Exists(path)) return;
                string script = File.ReadAllText(path, System.Text.Encoding.UTF8);
                await _core.AddScriptToExecuteOnDocumentCreatedAsync(script);
            }
            catch { }
        }

        private static string DescribeWebViewError(Exception ex)
        {
            string message = ex.Message;
            bool missing = ex.HResult == unchecked((int)0x80070002)
                || message.IndexOf("not found", StringComparison.OrdinalIgnoreCase) >= 0
                || message.IndexOf("无法找到", StringComparison.Ordinal) >= 0;

            if (missing)
            {
                message += "\n\n本机缺少 WebView2 运行时，请安装后重启本程序：\n"
                    + "https://go.microsoft.com/fwlink/p/?LinkId=2124703";
            }
            return message;
        }

        // ---------------------------------------------------------------- 右键菜单

        private void OnContextMenuRequested(object sender, CoreWebView2ContextMenuRequestedEventArgs e)
        {
            CoreWebView2Deferral deferral = e.GetDeferral();
            try
            {
                AddMenuItem(e, CoreWebView2ContextMenuItemKind.Separator, "", null);
                AddMenuItem(e, CoreWebView2ContextMenuItemKind.Command, "导出本页为 PDF（Ctrl+Shift+E）", ExportPdf);
                AddMenuItem(e, CoreWebView2ContextMenuItemKind.Command, "复制当前地址", CopyAddress);
                AddMenuItem(e, CoreWebView2ContextMenuItemKind.Command, "在浏览器中打开", delegate { OpenInBrowser(CurrentUrl); });
                AddMenuItem(e, CoreWebView2ContextMenuItemKind.Command, "刷新", Reload);
                AddMenuItem(e, CoreWebView2ContextMenuItemKind.Separator, "", null);
                AddMenuItem(e, CoreWebView2ContextMenuItemKind.Command, "退出登录（清除本站会话）", SignOut);
                AddMenuItem(e, CoreWebView2ContextMenuItemKind.Command, "关于（F1）", ShowAboutDialog);
            }
            catch { }
            finally
            {
                try { deferral.Complete(); } catch { }
            }
        }

        private void AddMenuItem(CoreWebView2ContextMenuRequestedEventArgs e,
            CoreWebView2ContextMenuItemKind kind, string label, Action action)
        {
            try
            {
                CoreWebView2ContextMenuItem item = _core.Environment.CreateContextMenuItem(
                    label ?? string.Empty, null, kind);

                if (action != null)
                {
                    item.CustomItemSelected += delegate
                    {
                        try { action(); } catch { }
                    };
                }

                e.MenuItems.Add(item);
            }
            catch { }
        }

        // ---------------------------------------------------------------- 导航策略

        private void OnNavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            Uri uri;
            if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out uri)) return;
            if (StoreInfo.IsBrowserInternal(uri)) return;
            if (StoreInfo.IsInAppHost(uri)) return;

            e.Cancel = true;
            OpenInBrowser(e.Uri);
        }

        private void OnNavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (e.IsSuccess)
            {
                HideOverlay();
                if (!string.IsNullOrEmpty(_pendingToast))
                {
                    string message = _pendingToast;
                    _pendingToast = null;
                    Toast(message, "info");
                }
                return;
            }

            if (e.WebErrorStatus == CoreWebView2WebErrorStatus.OperationCanceled) return;

            ShowError("无法连接到研海寻踪服务器",
                "加载失败：" + e.WebErrorStatus
                + "\n\n请检查网络（校园网/公司网络可能拦截 443），"
                + "或修改 config.json 中的 baseUrl。");
        }

        private void OnNewWindowRequested(object sender, CoreWebView2NewWindowRequestedEventArgs e)
        {
            e.Handled = true;

            Uri uri;
            if (Uri.TryCreate(e.Uri, UriKind.Absolute, out uri) && StoreInfo.IsInAppHost(uri))
            {
                Navigate(e.Uri);
                return;
            }
            OpenInBrowser(e.Uri);
        }

        private void OnDocumentTitleChanged(object sender, object e)
        {
            try
            {
                string title = _core.DocumentTitle;
                SetWindowTitle(string.IsNullOrWhiteSpace(title) ? StoreInfo.AppName : title);
            }
            catch { }
        }

        // ---------------------------------------------------------------- 下载

        private void OnDownloadStarting(object sender, CoreWebView2DownloadStartingEventArgs e)
        {
            string suggested = "";
            try { suggested = Path.GetFileName(e.ResultFilePath); } catch { }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Title = "保存下载文件";
                dlg.FileName = string.IsNullOrWhiteSpace(suggested) ? "download" : suggested;
                dlg.Filter = "所有文件|*.*";
                try
                {
                    dlg.InitialDirectory = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
                }
                catch { }

                if (dlg.ShowDialog(this) != DialogResult.OK)
                {
                    e.Cancel = true;
                    return;
                }

                e.ResultFilePath = dlg.FileName;
                e.Handled = true;
            }

            string target = e.ResultFilePath;
            Toast("开始下载 " + Path.GetFileName(target) + " …", "info");

            CoreWebView2DownloadOperation operation = e.DownloadOperation;
            operation.StateChanged += delegate
            {
                try
                {
                    BeginInvoke(new Action(delegate
                    {
                        if (operation.State == CoreWebView2DownloadState.Completed)
                            Toast("下载完成：" + operation.ResultFilePath, "info");
                        else if (operation.State == CoreWebView2DownloadState.Interrupted)
                            Toast("下载中断：" + operation.InterruptReason, "error");
                    }));
                }
                catch { }
            };
        }

        private void OnProcessFailed(object sender, CoreWebView2ProcessFailedEventArgs e)
        {
            BeginInvoke(new Action(delegate
            {
                Toast("渲染进程异常：" + e.ProcessFailedKind, "error");
                if (MessageBox.Show("渲染进程异常结束，是否重新加载页面？", StoreInfo.AppName,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    Reload();
                }
            }));
        }

        // ---------------------------------------------------------------- 操作

        public void Reload()
        {
            HideOverlay();
            try
            {
                if (_core != null) _core.Reload();
            }
            catch (Exception ex) { Toast("刷新失败：" + ex.Message, "error"); }
        }

        public void Navigate(string url)
        {
            if (string.IsNullOrWhiteSpace(url) || _core == null) return;
            try
            {
                HideOverlay();
                _core.Navigate(url);
            }
            catch (Exception ex) { Toast("导航失败：" + ex.Message, "error"); }
        }

        private string CurrentUrl
        {
            get
            {
                try
                {
                    if (_core != null && !string.IsNullOrWhiteSpace(_core.Source)) return _core.Source;
                }
                catch { }
                return _config.BaseUrl;
            }
        }

        private void CopyAddress()
        {
            try
            {
                Clipboard.SetText(CurrentUrl);
                Toast("已复制地址", "info");
            }
            catch (Exception ex) { Toast("复制失败：" + ex.Message, "error"); }
        }

        /// <summary>清除 WebView2 内的 Cookie 与 localStorage，等同退出登录。</summary>
        public async void SignOut()
        {
            if (MessageBox.Show("将清除本机保存的登录状态并返回工作台，继续？", StoreInfo.AppName,
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                if (_core != null)
                {
                    await _core.ExecuteScriptAsync(
                        "try{localStorage.clear();sessionStorage.clear();}catch(e){}");
                    _core.CookieManager.DeleteAllCookies();
                }
            }
            catch (Exception ex) { Toast("清除失败：" + ex.Message, "error"); }

            Toast("已清除本站登录状态", "info");
            Navigate(_config.BaseUrl);
        }

        public async void ExportPdf()
        {
            if (_core == null) return;

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Title = "导出当前页面为 PDF";
                dlg.Filter = "PDF 文件|*.pdf";
                dlg.FileName = "研海寻踪-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".pdf";
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    Toast("正在导出 PDF…", "info");
                    bool ok = await _core.PrintToPdfAsync(dlg.FileName, null);
                    if (!ok)
                    {
                        Toast("导出 PDF 失败", "error");
                        return;
                    }
                    Toast("已导出：" + dlg.FileName, "info");
                    if (MessageBox.Show("已导出到：\n" + dlg.FileName + "\n\n是否打开所在文件夹？", "导出完成",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Process.Start("explorer.exe", "/select,\"" + dlg.FileName + "\"");
                    }
                }
                catch (Exception ex)
                {
                    Toast("导出 PDF 失败：" + ex.Message, "error");
                }
            }
        }

        public void SetWindowTitle(string text)
        {
            Text = string.IsNullOrWhiteSpace(text) ? StoreInfo.AppName : text;
        }

        public void ShowAboutDialog()
        {
            string screen;
            try { screen = ScreenInfo.Describe(Handle); }
            catch { screen = "读取显示器信息失败"; }

            MessageBox.Show(
                StoreInfo.AppName + "  v" + StoreInfo.Version + "\n\n"
                + "工作台：" + _config.BaseUrl + "\n"
                + "WebView2 运行时：" + WebViewVersion + "\n"
                + "配置文件：" + _config.ConfigFilePath + "\n"
                + "会话数据：" + _config.ResolvedUserDataFolder() + "\n\n"
                + screen + "\n\n"
                + "界面、路由、登录与流式运行结果全部复用 snowsong.top 的网页版，"
                + "网页升级后客户端无需更新。\n"
                + "右键菜单与快捷键：Ctrl+Shift+E 导出 PDF、Ctrl+Shift+L 退出登录、F1 关于。",
                "关于", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static void OpenInBrowser(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return;
            try
            {
                Process.Start(url);
            }
            catch (Exception ex)
            {
                MessageBox.Show("无法打开浏览器：" + ex.Message, StoreInfo.AppName,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ---------------------------------------------------------------- 提示

        /// <summary>所有用户可见的状态都走网页内 toast，不再占用窗口空间。</summary>
        internal void Toast(string message, string kind)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(delegate { Toast(message, kind); }));
                return;
            }

            if (_core == null)
            {
                _pendingToast = message;
                return;
            }

            try
            {
                string text = JsonConvert.SerializeObject(message ?? string.Empty);
                string level = JsonConvert.SerializeObject(kind ?? "info");
                _core.ExecuteScriptAsync("window.__agentToast && window.__agentToast(" + text + "," + level + ");");
            }
            catch { }
        }

        private void HideOverlay()
        {
            if (_overlay != null) _overlay.Visible = false;
        }

        private void ShowError(string title, string detail)
        {
            if (_overlay == null) return;

            _overlayTitle.Text = title;
            _overlayDetail.Text = detail;
            _retryButton.Visible = true;
            _browserButton.Visible = true;
            _overlay.Visible = true;
            _overlay.BringToFront();
        }

        // ---------------------------------------------------------------- 生命周期

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_config.RememberWindowState) return;

            Rectangle bounds = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
            _config.WindowWidth = bounds.Width;
            _config.WindowHeight = bounds.Height;
            _config.WindowLeft = bounds.Left;
            _config.WindowTop = bounds.Top;
            _config.WindowMaximized = WindowState == FormWindowState.Maximized;
            _config.Save();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && webView != null)
            {
                try { webView.Dispose(); } catch { }
            }
            base.Dispose(disposing);
        }
    }
}
