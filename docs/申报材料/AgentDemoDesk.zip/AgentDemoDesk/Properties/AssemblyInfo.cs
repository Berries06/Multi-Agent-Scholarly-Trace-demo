﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("研海寻踪桌面端")]
[assembly: AssemblyDescription("研海寻踪 · 多智能体科研知识图谱 WebView2 桌面客户端")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("snowsong.top")]
[assembly: AssemblyProduct("AgentDemoDesk")]
[assembly: AssemblyCopyright("Copyright © snowsong.top")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("b6d0f3a1-6c1e-4c77-9e4b-2a8f5c31d0a7")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
