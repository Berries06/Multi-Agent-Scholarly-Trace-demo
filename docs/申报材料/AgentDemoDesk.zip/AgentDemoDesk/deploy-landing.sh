#!/usr/bin/env bash
# =============================================================================
#  deploy-landing.sh —— 把 /AgentDemo/ 落地页换成站点风格版本
#
#  在 WSL 里运行：
#      wsl -d Ubuntu-24.04 -- bash /mnt/d/project/CSharp/AgentDemoDesk/deploy-landing.sh
#
#  替换 /var/www/mysite/AgentDemo/index.html 与 landing.css；先备份到
#  /root/ops-backups/，再用 curl 验收页面、样式与关键链接。
# =============================================================================
set -euo pipefail

HOST="${SITE_HOST:-TencentCloud}"
ROOT=/mnt/d/project/CSharp/AgentDemoDesk
SRC="$ROOT/landing-page/index.html"
CSS="$ROOT/landing-page/landing.css"

[[ -f "$SRC" ]] || { echo "找不到 $SRC"; exit 1; }
[[ -f "$CSS" ]] || { echo "找不到 $CSS"; exit 1; }

echo "==> 1/3 上传落地页与样式"
scp -q "$SRC" "$HOST:/tmp/agentdemo-landing.htm"
scp -q "$CSS" "$HOST:/tmp/agentdemo-landing.css"

echo "==> 2/3 服务器侧备份并替换"
ssh "$HOST" bash -s <<'REMOTE'
set -euo pipefail
DEST=/var/www/mysite/AgentDemo
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP=/root/ops-backups/${STAMP}-agentdemo-landing

install -d -m 0700 "$BACKUP"
cp -a "$DEST/index.html" "$BACKUP/index.html"
[[ -f "$DEST/landing.css" ]] && cp -a "$DEST/landing.css" "$BACKUP/landing.css" || true

install -m 0644 -o root -g root /tmp/agentdemo-landing.htm "$DEST/index.html"
install -m 0644 -o root -g root /tmp/agentdemo-landing.css "$DEST/landing.css"
rm -f /tmp/agentdemo-landing.htm /tmp/agentdemo-landing.css

echo "    备份：$BACKUP"
ls -l "$DEST"
REMOTE

echo "==> 3/3 HTTP 验收"
for path in "/AgentDemo/" "/AgentDemo/landing.css" "/AgentDemo/start/" "/AgentDemo/install/" "/assets/site.css?v=20260927-log"; do
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 "https://snowsong.top$path")
  printf '    %-52s %s\n' "$path" "$code"
done

echo "---- 页面引用的样式与结构 ----"
curl -s https://snowsong.top/AgentDemo/ | grep -oE 'href="[^"]*\.css[^"]*"|lp-grid|lp-btn|site-footer|top-bar' | sort -u
