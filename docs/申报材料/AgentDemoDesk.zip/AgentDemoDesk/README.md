# AgentDemoDesk —— 研海寻踪 WebView2 桌面端

把 <https://snowsong.top/AgentDemo/> 包成 Windows 桌面应用。**界面、路由、登录、SSE 流式轨迹全部复用线上网页版**，C# 只做窗口与原生能力，因此网页发版后客户端不需要跟着更新。

## 与 `BMS_WinForms` 的关系

沿用它验证过的同一套工具方式：

| 项目 | 做法 |
|---|---|
| 运行时 | .NET Framework **4.7.2**（Win10/11 自带 4.8，无需装 .NET） |
| UI | WinForms + **WebView2 1.0.2903.40** |
| 桥 | `[ComVisible] JsBridge` + `AddHostObjectToScript("bridge", …)`，JS 侧 `window.chrome.webview.hostObjects.sync.bridge` |
| 构建 | MSBuild（VS 自带），`/t:Restore` + `/t:Build` |
| 发布 | `publish.ps1`：版本注入 → Release → 白名单复制 → zip → SHA-256 |

差别只有一处：`BMS_WinForms` 加载本地 `wwwroot`（虚拟主机映射），本项目直接导航线上站。

## 直接复用网页，不改网页

- 入口 `https://snowsong.top/AgentDemo/start/`（React SPA，nginx 反代 FastAPI）。
- 会话 Cookie 的 `Path=/AgentDemo/start/`，所以壳必须停在这个 origin + 路径下；`UserDataFolder` 固定为 `%LOCALAPPDATA%\AgentDemoDesk\WebView2`，登录状态可跨重启保留（服务端会话 14 天）。
- 站点 CSP（`style-src 'unsafe-inline'`、`frame-ancestors 'self'`）对顶层导航无影响。
- 图标直接取线上 PWA 的 `icon-512.png`，用 Pillow 转成 `Assets\AgentDemoDesk.ico`。
- 内核用 Evergreen Runtime（本机已装 155.0.4283.62），与 Edge 一同更新，包体约 1.7 MB。

## 原生能力

窗口里除网页外**没有任何常驻界面**：没有菜单栏、没有状态栏。原生功能走右键菜单与快捷键，提示走注入网页的右下角 toast。

| 入口 | 内容 |
|---|---|
| 右键菜单（在网页原有菜单后追加） | 导出本页为 PDF / 复制当前地址 / 在浏览器中打开 / 刷新 / 退出登录（清 Cookie + localStorage）/ 关于 |
| 快捷键 | `F5` 刷新、`Alt+←/→` 前进后退（WebView2 原生）、`Ctrl+Shift+E` 导出 PDF、`Ctrl+Shift+L` 退出登录、`F1` 关于 |
| 下载 | `DownloadStarting` → 另存为对话框，开始/完成/中断都弹出 toast |
| 外链策略 | 仅 `snowsong.top`、`127.0.0.1`、`localhost` 在应用内；GitHub 等站外交给系统浏览器；`NewWindowRequested` 同样处理 |
| 兜底 | 加载失败覆盖层（重试 / 在浏览器中打开）、`ProcessFailed` 询问重载、WebView2 缺失时给官方安装链接 |
| 其他 | 单实例 Mutex、首次启动最大化并记忆窗口位置/大小、窗口标题跟随页面 |

## 界面密度与清晰度

- `app.manifest` + `App.config` + `Program.Main` 三处把进程声明为 **Per-Monitor V2**；
  否则在 150% 缩放的屏幕上 Windows 会把 96 DPI 位图放大 1.5 倍，文字发虚（本机实测过这个状态）。
- 密度**只跟随系统缩放**：不设置 `--force-device-scale-factor`，也不做滚轮缩放
  （`IsZoomControlEnabled = false`，`ZoomFactor` 固定 1.0）。屏幕 2560×1600 @150% 时，
  WebView2 的 CSS 视口约 1707×1018，正好落在站点 ≥1280 的桌面断点里。
- "关于"对话框会打印当前显示器分辨率、缩放比例与可用 CSS 视口，便于现场核对。

## 429 的两层处理

- **服务端（根治）**：`/etc/nginx/conf.d/agentdemo-rate-limit.conf` 由 `rate=60r/m` 改为 `rate=4r/s`，
  `burst` 由 20 提到 80，并加 `Retry-After: 1` 与 `limit_req_log_level warn`。
  实测 80 个并发 + 持续 4 次/秒 全部 200。
- **客户端（兜底）**：`Assets\inject.js` 包装 `window.fetch`——最多 4 个并发、遇 429 按
  `Retry-After` 退避重试 3 次并弹 toast；`Accept: text/event-stream` 的 SSE 请求原样透传，
  不排队、不重试。

## 构建与运行

```powershell
$msbuild = 'D:\coding\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe'
& $msbuild .\AgentDemoDesk.csproj /t:Restore /p:Configuration=Release
& $msbuild .\AgentDemoDesk.csproj /t:Build   /p:Configuration=Release
.\bin\Release\AgentDemoDesk.exe
```

## 发布

```powershell
.\publish.ps1                # 默认 V1.0
.\publish.ps1 -Version V1.1  # 指定版本
```

产物有两份，内容一致：

- 目录：`release\AgentDemoDesk_V1.0\`（**解压即用**，双击 `AgentDemoDesk.exe`）
- 压缩包：`release\AgentDemoDesk-Windows-x64-V1.0.zip`（同目录内容的 zip，用于分发）

`release\AgentDemoDesk_V1.0\` 内含运行所需的全部文件（共 13 个文件、约 1.9 MB）：

```text
AgentDemoDesk.exe                              # 主程序
AgentDemoDesk.exe.config                       # .NET 4.7.2 运行时声明
config.json                                    # 服务器地址等默认配置（可改）
Microsoft.Web.WebView2.Core.dll                # WebView2 托管库
Microsoft.Web.WebView2.WinForms.dll
Microsoft.Web.WebView2.Wpf.dll
Newtonsoft.Json.dll                            # config.json 序列化
Assets\AgentDemoDesk.ico                       # 窗口/任务栏图标
Assets\icon-512.png                            # 关于对话框用图
Assets\inject.js                                # toast / 快捷键 / 429 退避重试注入脚本
runtimes\win-x64\native\WebView2Loader.dll     # x64 原生加载器
runtimes\win-x86\native\WebView2Loader.dll     # x86（AnyCPU 兜底）
runtimes\win-arm64\native\WebView2Loader.dll   # arm64（AnyCPU 兜底）
```

不打包的东西：`*.pdb` 调试符号、`*.exe.WebView2` 运行缓存、`logs`。运行时会话写入 `%LOCALAPPDATA%\AgentDemoDesk\WebView2`，不落在程序目录。

## 落地页（`/AgentDemo/`）

源文件在 `landing-page/`：`index.html` + `landing.css`。版式是**四个大按钮 + 产品介绍**，视觉跟站点一致：

| 区块 | 实现 |
|---|---|
| 导航 / 页脚 | 站点 `nav.top-bar` 与 `footer.site-footer`；`AGENTDEMO` 用 `aria-current="page"` 高亮 |
| 页头 | mono kicker + 大标题 + 两行说明 + `PUBLIC VALIDATION · 0.1.0` 徽标 |
| 四个大按钮 | `.lp-grid` / `.lp-btn`：2×2 栅格，每块 176px 高，hover 整块反转为黑底白字 |
| 产品介绍 | `这套系统在做什么`：六步闭环（诊断→检索→提出→批判→裁判→资源生成）+ 三种使用方式（离线 Mock / 服务器免费 DeepSeek / BYOK） |
| 已移除 | 03 CPU LAB、04 GPU LAB 两个未开机入口，以及“使用边界”警告 callout |

`landing.css`（约 2.6 KB）只写栅格与产品介绍区的间距；颜色、字体取自 `/assets/site.css` 的变量，不新增配色。

一键发布（会先备份线上 `index.html` 与 `landing.css`）：

```bash
wsl -d Ubuntu-24.04 -- bash /mnt/d/project/CSharp/AgentDemoDesk/deploy-landing.sh
```

## 下载页（`/AgentDemo/install/`）

源文件在 `install-page/`：`index.html` + `install.css`。**视觉中心是一个整宽的下载大按钮**（`.dl-hero`，
黑底白字、hover 反转），下面才是次要的「网页版 / GitHub」按钮，然后是安装步骤、系统要求、校验、排查、版本。

- **只提供 WebView2 桌面端**：Qt 验证版（`YanhaiTrace-Windows-x64-0.1.0.zip`）已从服务器彻底删除，
  页面上的对比表、校验表和相关文案也一并移除，`deploy-install.sh` 会顺带清理这个遗留文件。
- 该目录的 CSP 是 `default-src 'self'; style-src 'self'`，因此样式必须是同源外部文件（`install.css`），
  不能内联 `<style>` 或 `style=""`。

一键发布：

```bash
wsl -d Ubuntu-24.04 -- bash /mnt/d/project/CSharp/AgentDemoDesk/deploy-install.sh V1.1
```
## 配置 `config.json`

```json
{
  "baseUrl": "https://snowsong.top/AgentDemo/start/",
  "allowDevTools": false,
  "rememberWindowState": true,
  "startMaximized": true,
  "windowWidth": 1360,
  "windowHeight": 860,
  "windowMaximized": false,
  "userDataFolder": ""
}
```

只有一个入口 `baseUrl`（工作台）。把 `baseUrl` 切到 `http://127.0.0.1:5173/` 即可对接本地 Vite 调试
（页面会自动用 `/api` 前缀，后端 CORS 已放行 5173）。
刻意没有"缩放/密度"配置项：界面密度只跟随系统 DPI。

## 已知边界

- 纯在线壳：离线无法使用离线规则模式（那需要 FastAPI 后端，属于另一套本地服务，不在本壳范围内）。
- 未做代码签名，首次运行可能出现"未知发布者"，以安装页的 SHA-256 为准（与 Qt 版一致）。
- 包装 `demo` 里的 PDF 上传走 WebView2 原生文件对话框，无需额外代码。
