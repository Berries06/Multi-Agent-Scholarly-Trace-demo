using System;
using System.IO;
using Newtonsoft.Json;

namespace AgentDemoDesk.Utils
{
    /// <summary>
    /// 应用配置。config.json 与程序同目录，发布包自带一份默认值。
    /// 刻意不提供"强制缩放/密度"选项：界面密度完全跟随系统 DPI，
    /// 由 app.manifest 的 PerMonitorV2 保证原生像素渲染。
    /// </summary>
    public class AppConfig
    {
        /// <summary>唯一的入口：工作台（React SPA，nginx 反代到 FastAPI）。</summary>
        public string BaseUrl { get; set; } = "https://snowsong.top/AgentDemo/start/";

        public bool AllowDevTools { get; set; } = false;

        public bool RememberWindowState { get; set; } = true;

        /// <summary>首次启动（或没有保存过窗口位置）时直接最大化。</summary>
        public bool StartMaximized { get; set; } = true;

        public int WindowWidth { get; set; } = 1360;
        public int WindowHeight { get; set; } = 860;
        public int WindowLeft { get; set; } = int.MinValue;
        public int WindowTop { get; set; } = int.MinValue;
        public bool WindowMaximized { get; set; } = false;

        /// <summary>留空时使用 %LOCALAPPDATA%\AgentDemoDesk\WebView2。</summary>
        public string UserDataFolder { get; set; } = "";

        [JsonIgnore]
        public string ConfigFilePath
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.json"); }
        }

        /// <summary>
        /// WebView2 的会话 Cookie 与 localStorage 都落在这里；路径固定，
        /// 服务端 14 天会话才能在重启后继续有效。
        /// </summary>
        public string ResolvedUserDataFolder()
        {
            if (!string.IsNullOrWhiteSpace(UserDataFolder)) return UserDataFolder;

            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AgentDemoDesk",
                "WebView2");
        }

        public void Save()
        {
            try
            {
                File.WriteAllText(ConfigFilePath, JsonConvert.SerializeObject(this, Formatting.Indented));
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("保存配置失败: " + ex.Message);
            }
        }

        public static AppConfig Load()
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.json");
            try
            {
                if (File.Exists(path))
                {
                    AppConfig config = JsonConvert.DeserializeObject<AppConfig>(File.ReadAllText(path));
                    if (config != null)
                    {
                        config.Normalize();
                        return config;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("加载配置失败: " + ex.Message);
            }

            return new AppConfig();
        }

        private void Normalize()
        {
            if (string.IsNullOrWhiteSpace(BaseUrl))
                BaseUrl = "https://snowsong.top/AgentDemo/start/";
            if (!BaseUrl.EndsWith("/", StringComparison.Ordinal))
                BaseUrl += "/";
            if (WindowWidth < 960) WindowWidth = 1360;
            if (WindowHeight < 640) WindowHeight = 860;
        }
    }
}
