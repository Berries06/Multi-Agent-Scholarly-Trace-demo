using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace AgentDemoDesk.Utils
{
    /// <summary>
    /// 读取当前显示器与系统缩放。进程是 Per-Monitor V2 感知，
    /// 因此这里拿到的就是物理像素与真实 DPI，而不是被虚拟化后的值。
    /// </summary>
    public static class ScreenInfo
    {
        private const int MonitorDefaultToNearest = 2;

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);

        [DllImport("user32.dll")]
        private static extern uint GetDpiForWindow(IntPtr hwnd);

        [DllImport("shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr monitor, int dpiType, out uint dpiX, out uint dpiY);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr value);

        [DllImport("shcore.dll")]
        private static extern int SetProcessDpiAwareness(int value);

        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();

        private static readonly IntPtr PerMonitorAwareV2 = new IntPtr(-4);

        /// <summary>
        /// app.manifest 已经声明 PerMonitorV2；这里再显式设置一次作为兜底
        /// （清单被剥离、或被宿主替换时仍然生效）。必须在创建任何窗口之前调用。
        /// </summary>
        public static void EnablePerMonitorAwareness()
        {
            try
            {
                if (SetProcessDpiAwarenessContext(PerMonitorAwareV2)) return;
            }
            catch { }

            try
            {
                if (SetProcessDpiAwareness(2) == 0) return; // PER_MONITOR_DPI_AWARE
            }
            catch { }

            try { SetProcessDPIAware(); } catch { }
        }

        /// <summary>窗口所在显示器的有效 DPI（96 = 100%）。</summary>
        public static uint DpiForWindow(IntPtr hwnd)
        {
            try
            {
                uint dpi = GetDpiForWindow(hwnd);
                if (dpi > 0) return dpi;
            }
            catch { }

            try
            {
                IntPtr monitor = MonitorFromWindow(hwnd, MonitorDefaultToNearest);
                uint x, y;
                if (GetDpiForMonitor(monitor, 0, out x, out y) == 0 && x > 0) return x;
            }
            catch { }

            using (Graphics g = Graphics.FromHwnd(IntPtr.Zero))
            {
                return (uint)Math.Round(96.0 * g.DpiX / 96.0);
            }
        }

        public static string ScaleText(uint dpi)
        {
            if (dpi == 0) dpi = 96;
            return (dpi * 100 / 96) + "%（DPI " + dpi + "）";
        }

        /// <summary>多显示器概要，用于"关于"对话框。</summary>
        public static string Describe(IntPtr hwnd)
        {
            StringBuilder sb = new StringBuilder();
            uint current = DpiForWindow(hwnd);
            sb.Append("当前显示器缩放：").Append(ScaleText(current)).AppendLine();

            Screen[] screens = Screen.AllScreens;
            for (int i = 0; i < screens.Length; i++)
            {
                Screen screen = screens[i];
                sb.Append("显示器 ").Append(i + 1)
                  .Append(screen.Primary ? "（主）" : "")
                  .Append("：").Append(screen.Bounds.Width).Append(" × ").Append(screen.Bounds.Height)
                  .Append(" 物理像素，工作区 ").Append(screen.WorkingArea.Width).Append(" × ").Append(screen.WorkingArea.Height)
                  .AppendLine();
            }

            using (Graphics g = Graphics.FromHwnd(IntPtr.Zero))
            {
                sb.Append("WebView2 可用 CSS 视口：约 ")
                  .Append((int)Math.Floor(screens[0].WorkingArea.Width * 96.0 / current))
                  .Append(" × ")
                  .Append((int)Math.Floor(screens[0].WorkingArea.Height * 96.0 / current))
                  .Append("（跟随系统缩放，未强制覆盖）");
            }
            return sb.ToString();
        }
    }
}
