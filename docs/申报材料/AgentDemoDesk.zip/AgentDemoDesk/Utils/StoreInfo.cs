using System;
using System.Reflection;

namespace AgentDemoDesk.Utils
{
    /// <summary>应用标识与白名单。只影响“哪个站点在应用内打开”。</summary>
    public static class StoreInfo
    {
        public const string AppName = "研海寻踪桌面端";
        public const string AppId = "AgentDemoDesk";

        /// <summary>允许在应用内打开的站点主机（线上站 + 本地开发服务器）。</summary>
        private static readonly string[] InAppHosts =
        {
            "snowsong.top",
            "www.snowsong.top",
            "127.0.0.1",
            "localhost"
        };

        public static string Version
        {
            get
            {
                try
                {
                    Version v = Assembly.GetExecutingAssembly().GetName().Version;
                    return v.Major + "." + v.Minor + "." + Math.Max(v.Build, 0);
                }
                catch
                {
                    return "1.0.0";
                }
            }
        }

        /// <summary>
        /// 站点内链接留在 WebView2，站外链接交给系统浏览器——避免壳内出现
        /// 无法后退的“第三方页面”，也保证 GitHub 等外链用用户自己的浏览器会话。
        /// </summary>
        public static bool IsInAppHost(Uri uri)
        {
            if (uri == null) return false;
            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps) return false;

            string host = uri.Host ?? "";
            foreach (string allowed in InAppHosts)
            {
                if (string.Equals(host, allowed, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        /// <summary>about:/data:/blob: 等非 http(s) 文档由 WebView2 自己处理。</summary>
        public static bool IsBrowserInternal(Uri uri)
        {
            if (uri == null) return true;
            return uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps;
        }
    }
}
