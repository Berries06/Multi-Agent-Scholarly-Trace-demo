#!/usr/bin/env bash
# =============================================================================
#  deploy-install.sh —— 同步桌面端发布包与下载页到 snowsong.top
#
#  在 WSL 里运行：
#      wsl -d Ubuntu-24.04 -- bash /mnt/d/project/CSharp/AgentDemoDesk/deploy-install.sh [V1.1]
#
#  做四件事：
#   1. 校验本地 release zip 存在并算 SHA-256；
#   2. 上传 index.html / install.css / zip 到服务器 /tmp；
#   3. 备份线上 index.html 与 install.css，再原子 install 到 install/ 目录；
#      （并清理已下线的 Qt 客户端包，避免留下没人再发的 36 MB 死文件）
#   4. curl 验收页面、样式、包与站点 CSS。
# =============================================================================
set -euo pipefail

VERSION="${1:-V1.1}"
HOST="${SITE_HOST:-TencentCloud}"
ROOT=/mnt/d/project/CSharp/AgentDemoDesk
ZIP="AgentDemoDesk-Windows-x64-$VERSION.zip"
RETIRED_ZIP="YanhaiTrace-Windows-x64-0.1.0.zip"

[[ -f "$ROOT/release/$ZIP" ]] || { echo "找不到 $ROOT/release/$ZIP，先跑 publish.ps1 -Version $VERSION"; exit 1; }

LOCAL_SHA=$(sha256sum "$ROOT/release/$ZIP" | cut -d' ' -f1)
echo "==> 本地包：$ZIP"
echo "    SHA-256: $LOCAL_SHA"

echo "==> 1/4 上传"
scp -q "$ROOT/release/$ZIP" "$HOST:/tmp/$ZIP"
scp -q "$ROOT/install-page/index.html" "$HOST:/tmp/agentdemo-install-index.html"
scp -q "$ROOT/install-page/install.css" "$HOST:/tmp/agentdemo-install.css"

echo "==> 2/4 服务器侧备份并安装"
ssh "$HOST" bash -s -- "$ZIP" "$LOCAL_SHA" "$RETIRED_ZIP" <<'REMOTE'
set -euo pipefail
ZIP="$1"; SHA="$2"; RETIRED="$3"; DEST=/var/www/mysite/AgentDemo/install
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP=/root/ops-backups/${STAMP}-agentdemo-install

ACTUAL=$(sha256sum "/tmp/$ZIP" | cut -d' ' -f1)
[[ "$ACTUAL" == "$SHA" ]] || { echo "  上传后哈希不符：$ACTUAL"; exit 1; }

install -d -m 0700 "$BACKUP"
[[ -f "$DEST/index.html" ]] && cp -a "$DEST/index.html" "$BACKUP/index.html" || true
[[ -f "$DEST/install.css" ]] && cp -a "$DEST/install.css" "$BACKUP/install.css" || true
[[ -f "$DEST/styles.css" ]] && cp -a "$DEST/styles.css" "$BACKUP/styles.css" || true
echo "    备份：$BACKUP"

install -m 0644 -o root -g root /tmp/agentdemo-install-index.html "$DEST/index.html"
install -m 0644 -o root -g root /tmp/agentdemo-install.css "$DEST/install.css"
install -m 0644 -o root -g root "/tmp/$ZIP" "$DEST/$ZIP"
rm -f /tmp/agentdemo-install-index.html /tmp/agentdemo-install.css "/tmp/$ZIP"

# 已下线的遗留文件：旧独立样式表与 Qt 客户端包
rm -f "$DEST/styles.css"
if [[ -f "$DEST/$RETIRED" ]]; then
  rm -f "$DEST/$RETIRED"
  echo "    已删除下线的 Qt 客户端包：$RETIRED"
fi

ls -l "$DEST"
REMOTE

echo "==> 3/4 HTTP 验收"
for path in "/AgentDemo/install/" "/AgentDemo/install/install.css" "/AgentDemo/install/$ZIP" "/assets/site.css?v=20260927-log"; do
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 "https://snowsong.top$path")
  printf '    %-58s %s\n' "$path" "$code"
done
echo -n "    已下线 Qt 包（应为 404）: "
curl -s -o /dev/null -w '%{http_code}\n' --max-time 15 "https://snowsong.top/AgentDemo/install/$RETIRED_ZIP"

echo "==> 4/4 页面结构"
curl -s https://snowsong.top/AgentDemo/install/ | grep -oE 'href="[^"]*\.css[^"]*"|dl-hero|dl-hero-title|YanhaiTrace[^"<]*' | sort -u
