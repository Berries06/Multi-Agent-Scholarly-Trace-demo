/* 注入到每个页面的脚本：右下角 toast、快捷键、429 退避重试。
   由 MainForm 通过 AddScriptToExecuteOnDocumentCreatedAsync 注入，
   不修改线上网页源码。 */
(function () {
  if (window.__agentDemoDesk) return;
  window.__agentDemoDesk = { installed: true };

  // ---------------------------------------------------------------- toast
  var hostNode = null;

  function ensureStyle() {
    if (document.getElementById('__agent-style')) return;
    var style = document.createElement('style');
    style.id = '__agent-style';
    style.textContent =
      '#__agent-toasts{position:fixed;right:16px;bottom:16px;z-index:2147483647;display:flex;' +
      'flex-direction:column;gap:8px;pointer-events:none;font-family:system-ui,"Microsoft YaHei UI",sans-serif}' +
      '#__agent-toasts .__t{max-width:380px;background:#1E3932;color:#F2F0EB;padding:10px 14px;' +
      'border-radius:10px;font-size:13px;line-height:1.5;box-shadow:0 6px 24px rgba(0,0,0,.28);' +
      'opacity:0;transform:translateY(6px);transition:opacity .18s ease,transform .18s ease}' +
      '#__agent-toasts .__t.__show{opacity:1;transform:none}' +
      '#__agent-toasts .__t.__warn{background:#7A4B1E}' +
      '#__agent-toasts .__t.__err{background:#7A1E1E}';
    (document.head || document.documentElement).appendChild(style);
  }

  function toastHost() {
    if (hostNode && document.body && document.body.contains(hostNode)) return hostNode;
    hostNode = document.getElementById('__agent-toasts');
    if (!hostNode) {
      hostNode = document.createElement('div');
      hostNode.id = '__agent-toasts';
      (document.body || document.documentElement).appendChild(hostNode);
    }
    return hostNode;
  }

  window.__agentToast = function (message, kind) {
    try {
      ensureStyle();
      var node = document.createElement('div');
      node.className = '__t' + (kind === 'warn' ? ' __warn' : kind === 'error' ? ' __err' : '');
      node.textContent = String(message == null ? '' : message);
      toastHost().appendChild(node);
      window.requestAnimationFrame(function () { node.classList.add('__show'); });
      window.setTimeout(function () {
        node.classList.remove('__show');
        window.setTimeout(function () {
          if (node.parentNode) node.parentNode.removeChild(node);
        }, 250);
      }, 3600);
      return true;
    } catch (e) {
      return false;
    }
  };

  // ---------------------------------------------------------------- 快捷键
  function getBridge() {
    try {
      if (!window.chrome || !window.chrome.webview || !window.chrome.webview.hostObjects) return null;
      var objs = window.chrome.webview.hostObjects;
      return (objs.sync && objs.sync.bridge) || objs.bridge || null;
    } catch (e) {
      return null;
    }
  }

  document.addEventListener('keydown', function (ev) {
    var key = ev.key || '';
    var isE = key === 'E' || key === 'e';
    var isL = key === 'L' || key === 'l';

    if (ev.ctrlKey && ev.shiftKey && isE) { ev.preventDefault(); var b1 = getBridge(); if (b1) b1.printToPdf(); return; }
    if (ev.ctrlKey && ev.shiftKey && isL) { ev.preventDefault(); var b2 = getBridge(); if (b2) b2.signOut(); return; }
    if (key === 'F1') { ev.preventDefault(); var b3 = getBridge(); if (b3) b3.showAbout(); return; }
  }, true);

  // ---------------------------------------------------------------- 429 兜底
  (function () {
    if (window.__agentFetchGuard) return;
    window.__agentFetchGuard = true;

    var MAX_CONCURRENT = 4;
    var MAX_RETRIES = 3;
    var active = 0;
    var queue = [];
    var nativeFetch = window.fetch ? window.fetch.bind(window) : null;
    if (!nativeFetch) return;

    function pump() {
      while (active < MAX_CONCURRENT && queue.length > 0) {
        var job = queue.shift();
        active++;
        job();
      }
    }

    function headerValue(headers, name) {
      try {
        if (!headers) return '';
        if (typeof headers.get === 'function') return headers.get(name) || '';
        for (var k in headers) {
          if (k.toLowerCase() === name.toLowerCase()) return String(headers[k]);
        }
      } catch (e) { }
      return '';
    }

    window.fetch = function (input, init) {
      // SSE 必须原样透传，不能被重试或排队。
      var accept = headerValue(init && init.headers, 'Accept');
      if (/text\/event-stream/i.test(accept)) return nativeFetch(input, init);

      return new Promise(function (resolve, reject) {
        var attempt = 0;

        function run() {
          nativeFetch(input, init).then(function (response) {
            if (response && response.status === 429 && attempt < MAX_RETRIES) {
              attempt++;
              var retryAfter = parseInt(response.headers.get('Retry-After') || '0', 10);
              var delay = retryAfter > 0 ? retryAfter * 1000 : (attempt === 1 ? 700 : attempt === 2 ? 1600 : 3200);
              if (window.__agentToast) {
                window.__agentToast('请求过于频繁，正在重试（' + attempt + '/' + MAX_RETRIES + '）', 'warn');
              }
              window.setTimeout(run, delay);
              return;
            }
            active--;
            pump();
            resolve(response);
          }, function (error) {
            active--;
            pump();
            reject(error);
          });
        }

        queue.push(run);
        pump();
      });
    };
  })();
})();
