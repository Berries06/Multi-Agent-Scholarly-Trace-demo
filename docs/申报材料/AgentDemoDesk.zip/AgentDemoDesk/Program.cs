using System;
using System.Windows.Forms;
using AgentDemoDesk.Forms;
using AgentDemoDesk.Utils;

namespace AgentDemoDesk
{
    internal static class Program
    {
        private static System.Threading.Mutex _singleInstance;

        [STAThread]
        private static void Main()
        {
            // 必须在任何窗口创建之前：让进程按显示器真实 DPI 渲染，
            // 否则 150% 缩放下会被 Windows 位图拉伸而发虚。
            ScreenInfo.EnablePerMonitorAwareness();

            bool createdNew;
            _singleInstance = new System.Threading.Mutex(true, @"Local\AgentDemoDesk.SingleInstance", out createdNew);
            if (!createdNew)
            {
                MessageBox.Show("研海寻踪桌面端已经在运行。", "研海寻踪",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.ThreadException += (s, e) =>
                MessageBox.Show(e.Exception.Message, "异常", MessageBoxButtons.OK, MessageBoxIcon.Error);

            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
                MessageBox.Show(Convert.ToString(e.ExceptionObject), "未处理异常",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            try
            {
                Application.Run(new MainForm());
            }
            finally
            {
                if (_singleInstance != null) _singleInstance.ReleaseMutex();
            }
        }
    }
}
